"""
Shadow Editor v0.8.0 — Flet Edition
=====================================
Editeur de texte moderne avec interface Clean SaaS inspiree Notion / Untitled UI.

Fonctionnalites :
  - Onglets multiples avec gestion individuelle des fichiers
  - Calculatrice integree (parser AST securise)
  - Text-to-Speech et Speech-to-Text (non-bloquant via threading)
  - Correcteur IA local : ministral-3:3b via Ollama
  - Correcteur orthographique de base (pyspellchecker) en fallback
  - Remplacement automatique d'emojis (400+ codes)
  - Barre d'outils de formatage flottante
  - Themes sombre / clair avec design epure
  - Mode Texte / Mode Calcul / Mode Lecture
  - Selecteur visuel d'emojis avec recherche
  - Panneau lateral de corrections IA

Auteur  : Arnaud
Licence : CC BY-NC-ND 4.0
Version : 0.8.0
"""

# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------
import ast
import operator
import os
import sys
import threading
from datetime import datetime

import flet as ft

# Imports tiers optionnels
try:
    import pyttsx3
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False

try:
    import speech_recognition as sr
    SR_AVAILABLE = True
except ImportError:
    SR_AVAILABLE = False

try:
    from spellchecker import SpellChecker
    SPELL_AVAILABLE = True
except ImportError:
    SPELL_AVAILABLE = False

try:
    import win32print
    import win32ui
    import win32con
    WIN32_PRINT = True
except ImportError:
    WIN32_PRINT = False

# Imports locaux
from phrase_random import PhrasePlaceHolder
from my_emoji import EMOJI_DICT, EMOJI_CATEGORIES
from ai_checker import (
    OllamaManager,
    GrammarChecker,
    OllamaInstaller,
    ModelPuller,
    OLLAMA_MODEL,
    MODEL_SIZE_DISPLAY,
)


# ===========================================================================
# Constantes
# ===========================================================================

APP_NAME = "Carib Text Editor"
APP_VERSION = "0.8.0"

_SAFE_OPS: dict = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.Pow: operator.pow, ast.Mod: operator.mod,
    ast.USub: operator.neg, ast.UAdd: operator.pos,
}

MODE_TEXT = "text"
MODE_CALC = "calc"
MODE_READ = "read"


# ===========================================================================
# Design tokens
# ===========================================================================

class T:
    # Light
    L_BG        = "#FFFFFF"
    L_SIDEBAR   = "#F9FAFB"
    L_SURFACE   = "#FFFFFF"
    L_BORDER    = "#EAECF0"
    L_HOVER     = "#F3F4F6"
    L_SELECTED  = "#EEF2FF"
    L_PRIMARY   = "#101828"
    L_SECONDARY = "#344054"
    L_TERTIARY  = "#667085"
    L_MUTED     = "#98A2B3"
    L_ACCENT    = "#6366F1"
    L_ACCENT_LT = "#EEF2FF"
    L_SUCCESS   = "#059669"
    L_WARNING   = "#D97706"
    L_ERROR     = "#DC2626"
    L_TOOLBAR   = "#FFFFFF"
    L_TB_BORDER = "#E5E7EB"
    L_EDITOR    = "#FFFFFF"
    L_STATUS    = "#F9FAFB"
    # Dark
    D_BG        = "#0F172A"
    D_SIDEBAR   = "#0F172A"
    D_SURFACE   = "#1E293B"
    D_BORDER    = "#334155"
    D_HOVER     = "#1E293B"
    D_SELECTED  = "#312E81"
    D_PRIMARY   = "#F8FAFC"
    D_SECONDARY = "#CBD5E1"
    D_TERTIARY  = "#94A3B8"
    D_MUTED     = "#64748B"
    D_ACCENT    = "#818CF8"
    D_ACCENT_LT = "#1E1B4B"
    D_SUCCESS   = "#34D399"
    D_WARNING   = "#FBBF24"
    D_ERROR     = "#F87171"
    D_TOOLBAR   = "#1E293B"
    D_TB_BORDER = "#334155"
    D_EDITOR    = "#0F172A"
    D_STATUS    = "#0F172A"


# ===========================================================================
# Helpers
# ===========================================================================

def resource_path(rel: str) -> str:
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)


def eval_safe(expression: str) -> str:
    def _eval(node):
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp):
            fn = _SAFE_OPS.get(type(node.op))
            if fn:
                return fn(_eval(node.left), _eval(node.right))
        if isinstance(node, ast.UnaryOp):
            fn = _SAFE_OPS.get(type(node.op))
            if fn:
                return fn(_eval(node.operand))
        raise ValueError
    try:
        tree = ast.parse(expression, mode="eval")
        result = _eval(tree.body)
        return str(int(result)) if isinstance(result, float) and result.is_integer() else str(result)
    except ZeroDivisionError:
        return "Erreur : division par zéro"
    except Exception:
        return "Erreur de calcul"


# ===========================================================================
# Application
# ===========================================================================

async def main(page: ft.Page):
    # ------------------------------------------------------------------
    # Page config
    # ------------------------------------------------------------------
    page.title = f"{APP_NAME} — v{APP_VERSION}"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 0
    page.spacing = 0
    page.window = ft.Window(width=1280, height=820, min_width=800, min_height=550)
    page.theme = ft.Theme(font_family="Inter")
    page.dark_theme = ft.Theme(font_family="Inter")

    # Spellchecker
    spell = None
    if SPELL_AVAILABLE:
        try:
            spell = SpellChecker(
                local_dictionary=resource_path("ressource/spellchecker/fr.json.gz")
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # State
    # ------------------------------------------------------------------
    class S:
        docs: list = []
        idx: int = 0
        mode: str = MODE_TEXT
        show_ai: bool = False
        show_tb: bool = False  # legacy, non utilisé
        sidebar_key: str = "docs"
        ai_corr: list = []
        ai_sugg: list = []
        ai_score: int = -1
        ai_loading: bool = False
        ai_error: str = ""
        checker: GrammarChecker | None = None
        tts_on: bool = False
        voice_on: bool = False

    s = S()
    s.docs.append({"title": "Sans titre", "content": "", "path": None, "mod": False})
    ph = PhrasePlaceHolder()

    # File picker
    file_picker = ft.FilePicker()
    page.services.append(file_picker)

    # ------------------------------------------------------------------
    # Theme helper
    # ------------------------------------------------------------------
    def dark():
        return page.theme_mode == ft.ThemeMode.DARK

    def c(l, d):
        return d if dark() else l

    def show_snack(msg, color=None):
        page.show_dialog(
            ft.SnackBar(
                content=ft.Text(msg, color="#FFFFFF", size=13),
                bgcolor=color or c(T.L_PRIMARY, T.D_SURFACE),
                duration=3000,
                open=True,
            )
        )

    def doc():
        return s.docs[s.idx] if 0 <= s.idx < len(s.docs) else None

    # ------------------------------------------------------------------
    # Editor field
    # ------------------------------------------------------------------
    editor = ft.TextField(
        multiline=True,
        min_lines=25,
        expand=True,
        border=ft.InputBorder.NONE,
        hint_text=ph.get_random_phrase(),
        hint_style=ft.TextStyle(size=15, color=c(T.L_MUTED, T.D_MUTED), italic=True),
        text_size=16,
        text_style=ft.TextStyle(size=16, height=1.7, color=c(T.L_PRIMARY, T.D_PRIMARY)),
        cursor_color=c(T.L_ACCENT, T.D_ACCENT),
        cursor_height=22,
        content_padding=ft.Padding(48, 8, 48, 40),
        bgcolor=ft.Colors.TRANSPARENT,
        focused_bgcolor=ft.Colors.TRANSPARENT,
    )

    # ------------------------------------------------------------------
    # Status bar
    # ------------------------------------------------------------------
    st_mode = ft.Text("Texte", size=12, color=c(T.L_ACCENT, T.D_ACCENT), weight=ft.FontWeight.W_500)
    st_msg = ft.Text("", size=12, color=c(T.L_TERTIARY, T.D_TERTIARY), expand=True)
    st_chars = ft.Text("0 car.", size=12, color=c(T.L_TERTIARY, T.D_TERTIARY))
    st_words = ft.Text("0 mots", size=12, color=c(T.L_TERTIARY, T.D_TERTIARY))

    def update_status():
        d = doc()
        if not d:
            return
        t = d["content"]
        st_chars.value = f"{len(t)} car."
        st_words.value = f"{len(t.split()) if t.strip() else 0} mots"
        st_mode.value = {"text": "Texte", "calc": "Calcul", "read": "Lecture"}.get(s.mode, "Texte")

    # ------------------------------------------------------------------
    # Text change handler
    # ------------------------------------------------------------------
    def on_text_changed(e):
        d = doc()
        if not d:
            return
        d["content"] = e.control.value or ""
        if not d["mod"]:
            d["mod"] = True
            rebuild()
            return
        update_status()
        check_emoji_auto()
        detect_calc()
        page.update()

    editor.on_change = on_text_changed

    # ------------------------------------------------------------------
    # Emoji auto-replace
    # ------------------------------------------------------------------
    def check_emoji_auto():
        d = doc()
        if not d or not d["content"]:
            return
        words = d["content"].split()
        if not words:
            return
        last = words[-1]
        emoji = EMOJI_DICT.get(last)
        if emoji:
            d["content"] = d["content"].rsplit(last, 1)[0] + emoji
            editor.value = d["content"]

    # ------------------------------------------------------------------
    # Calc mode
    # ------------------------------------------------------------------
    def detect_calc():
        if s.mode != MODE_CALC:
            return
        d = doc()
        if not d or not d["content"]:
            return
        lines = d["content"].split("\n")
        last = lines[-1].strip()
        if not last.endswith("="):
            return
        expr = last[:-1].strip()
        result = eval_safe(expr)
        lines[-1] = last + " " + result
        d["content"] = "\n".join(lines)
        editor.value = d["content"]

    # ------------------------------------------------------------------
    # Tab management
    # ------------------------------------------------------------------
    def add_tab(title="", content="", path=None):
        idx = len(s.docs)
        s.docs.append({"title": title or f"Sans titre {idx}", "content": content, "path": path, "mod": False})
        s.idx = idx
        sync_editor()
        rebuild()

    def switch_tab(idx):
        if idx == s.idx:
            return
        save_content()
        s.idx = idx
        sync_editor()
        rebuild()

    def close_tab(idx):
        if len(s.docs) <= 1:
            s.docs[0] = {"title": "Sans titre", "content": "", "path": None, "mod": False}
            s.idx = 0
            sync_editor()
            rebuild()
            return
        s.docs.pop(idx)
        if s.idx >= len(s.docs):
            s.idx = len(s.docs) - 1
        sync_editor()
        rebuild()

    def save_content():
        d = doc()
        if d:
            d["content"] = editor.value or ""

    def sync_editor():
        d = doc()
        if not d:
            return
        editor.value = d["content"]
        editor.read_only = (s.mode == MODE_READ)
        editor.hint_text = ph.get_random_phrase()
        update_status()

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------
    async def open_file(e=None):
        result = await file_picker.pick_files(
            dialog_title="Ouvrir un fichier",
            allowed_extensions=["txt"],
            allow_multiple=False,
        )
        if not result:
            return
        fp = result[0].path
        content = _read_file(fp)
        if content is None:
            show_snack("Impossible de lire le fichier.", c(T.L_ERROR, T.D_ERROR))
            return
        save_content()
        add_tab(title=os.path.basename(fp), content=content, path=fp)

    async def save_file(e=None):
        d = doc()
        if not d:
            return
        save_content()
        if d["path"]:
            _write_file(d)
        else:
            await save_file_as()

    async def save_file_as(e=None):
        d = doc()
        if not d:
            return
        save_content()
        path = await file_picker.save_file(
            dialog_title="Enregistrer le fichier",
            file_name=(d["title"] + ".txt"),
            allowed_extensions=["txt"],
        )
        if not path:
            return
        d["path"] = path
        d["title"] = os.path.basename(path)
        _write_file(d)

    def _write_file(d):
        try:
            with open(d["path"], "w", encoding="utf-8") as fh:
                fh.write(d["content"])
            d["mod"] = False
            show_snack(datetime.now().strftime("Enregistré le %d/%m/%Y à %Hh%M"), c(T.L_SUCCESS, T.D_SUCCESS))
            rebuild()
        except OSError as exc:
            show_snack(f"Erreur : {exc}", c(T.L_ERROR, T.D_ERROR))

    def _read_file(fp):
        for enc in ("utf-8", "latin-1"):
            try:
                with open(fp, "r", encoding=enc) as fh:
                    return fh.read()
            except UnicodeDecodeError:
                continue
            except OSError:
                return None
        return None

    def rename_file(e=None):
        d = doc()
        if not d:
            return
        base = d["title"]
        if base.lower().endswith(".txt"):
            base = base[:-4]
        name_field = ft.TextField(
            value=base, label="Nouveau nom", autofocus=True,
            border_radius=8, text_size=14,
            border_color=c(T.L_BORDER, T.D_BORDER),
            focused_border_color=c(T.L_ACCENT, T.D_ACCENT),
        )

        def do_rename(ev):
            new_name = (name_field.value or "").strip()
            if not new_name:
                return
            if not new_name.endswith(".txt"):
                new_name += ".txt"
            old_path = d["path"]
            d["title"] = new_name
            page.pop_dialog()
            if old_path:
                new_path = os.path.join(os.path.dirname(old_path), new_name)
                try:
                    os.rename(old_path, new_path)
                    d["path"] = new_path
                    show_snack(f"Renommé en {new_name}", c(T.L_SUCCESS, T.D_SUCCESS))
                except OSError as exc:
                    show_snack(f"Erreur : {exc}", c(T.L_ERROR, T.D_ERROR))
            else:
                show_snack(f"Renommé en {new_name}", c(T.L_SUCCESS, T.D_SUCCESS))
            rebuild()

        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Renommer le fichier", size=16, weight=ft.FontWeight.W_600),
            content=ft.Container(width=360, content=name_field),
            actions=[
                ft.TextButton("Annuler", on_click=lambda ev: page.pop_dialog()),
                ft.FilledButton("Renommer", on_click=do_rename),
            ],
        )
        page.show_dialog(dlg)

    def print_file(e=None):
        save_content()
        d = doc()
        if not d:
            return
        text = d["content"]
        if not text.strip():
            show_snack("Rien à imprimer.", c(T.L_WARNING, T.D_WARNING))
            return
        if not WIN32_PRINT:
            show_snack("pip install pywin32 requis pour imprimer.", c(T.L_WARNING, T.D_WARNING))
            return

        def _do_print():
            import ctypes
            import ctypes.wintypes as wt

            # ----------------------------------------------------------
            # Structure PRINTDLGW (version Unicode — pas de bug encodage)
            # ----------------------------------------------------------
            class PRINTDLGW(ctypes.Structure):
                _fields_ = [
                    ("lStructSize",        wt.DWORD),
                    ("hwndOwner",          wt.HWND),
                    ("hDevMode",           wt.HANDLE),
                    ("hDevNames",          wt.HANDLE),
                    ("hDC",                wt.HDC),
                    ("Flags",              wt.DWORD),
                    ("nFromPage",          wt.WORD),
                    ("nToPage",            wt.WORD),
                    ("nMinPage",           wt.WORD),
                    ("nMaxPage",           wt.WORD),
                    ("nCopies",            wt.WORD),
                    ("hInstance",          wt.HINSTANCE),
                    ("lCustData",          ctypes.POINTER(ctypes.c_long)),
                    ("lpfnPrintHook",      ctypes.c_void_p),
                    ("lpfnSetupHook",      ctypes.c_void_p),
                    ("lpPrintTemplateName", wt.LPCWSTR),
                    ("lpSetupTemplateName", wt.LPCWSTR),
                    ("hPrintTemplate",     wt.HANDLE),
                    ("hSetupTemplate",     wt.HANDLE),
                ]

            PD_RETURNDC    = 0x00000100
            PD_NOPAGENUMS  = 0x00000008
            PD_NOSELECTION = 0x00000004

            try:
                pd = PRINTDLGW()
                pd.lStructSize = ctypes.sizeof(PRINTDLGW)
                pd.Flags = PD_RETURNDC | PD_NOPAGENUMS | PD_NOSELECTION

                # Ouvre la boîte d'impression native Windows (Unicode)
                if not ctypes.windll.comdlg32.PrintDlgW(ctypes.byref(pd)):
                    return  # Annulé par l'utilisateur

                hdc = pd.hDC
                gdi = ctypes.windll.gdi32

                # Police 11 pt Courier New
                dpi_y = gdi.GetDeviceCaps(hdc, win32con.LOGPIXELSY)
                font_h = -int(11 * dpi_y / 72)
                hfont = gdi.CreateFontW(
                    font_h, 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 0, 0,
                    "Courier New"
                )
                gdi.SelectObject(hdc, hfont)

                # Dimensions page et marges 5 %
                page_w = gdi.GetDeviceCaps(hdc, win32con.HORZRES)
                page_h = gdi.GetDeviceCaps(hdc, win32con.VERTRES)
                margin_x = int(page_w * 0.05)
                margin_y = int(page_h * 0.05)
                max_y = page_h - margin_y

                # Hauteur de ligne via GetTextMetrics
                class TEXTMETRICW(ctypes.Structure):
                    _fields_ = [
                        ("tmHeight", ctypes.c_long),
                        ("tmAscent", ctypes.c_long),
                        ("tmDescent", ctypes.c_long),
                        ("tmInternalLeading", ctypes.c_long),
                        ("tmExternalLeading", ctypes.c_long),
                    ] + [(f"_pad{i}", ctypes.c_long) for i in range(15)]

                tm = TEXTMETRICW()
                gdi.GetTextMetricsW(hdc, ctypes.byref(tm))
                line_h = int((tm.tmHeight + tm.tmExternalLeading) * 1.2)

                # --- Impression via GDI Unicode ---
                class DOCINFOW(ctypes.Structure):
                    _fields_ = [
                        ("cbSize",      ctypes.c_int),
                        ("lpszDocName", wt.LPCWSTR),
                        ("lpszOutput",  wt.LPCWSTR),
                        ("lpszDatatype", wt.LPCWSTR),
                        ("fwType",      wt.DWORD),
                    ]

                di = DOCINFOW()
                di.cbSize = ctypes.sizeof(DOCINFOW)
                di.lpszDocName = d["title"] or "Sans titre"

                gdi.StartDocW(hdc, ctypes.byref(di))
                gdi.StartPage(hdc)
                y = margin_y

                for line in text.split("\n"):
                    if y + line_h > max_y:
                        gdi.EndPage(hdc)
                        gdi.StartPage(hdc)
                        y = margin_y
                    out = line if line else " "
                    gdi.TextOutW(hdc, margin_x, y, out, len(out))
                    y += line_h

                gdi.EndPage(hdc)
                gdi.EndDoc(hdc)
                gdi.DeleteObject(hfont)
                ctypes.windll.user32.ReleaseDC(None, hdc)

                page.run_thread(
                    lambda: show_snack("Impression terminée.", c(T.L_SUCCESS, T.D_SUCCESS))
                )
            except Exception as exc:
                msg = str(exc)
                page.run_thread(
                    lambda: show_snack(f"Erreur : {msg}", c(T.L_ERROR, T.D_ERROR))
                )

        threading.Thread(target=_do_print, daemon=True).start()

    # ------------------------------------------------------------------
    # Modes
    # ------------------------------------------------------------------
    def set_mode(mode):
        s.mode = mode
        editor.read_only = (mode == MODE_READ)
        update_status()
        show_snack({"text": "Mode texte", "calc": "Mode calcul", "read": "Mode lecture"}.get(mode, ""))
        rebuild()

    # ------------------------------------------------------------------
    # Spelling
    # ------------------------------------------------------------------
    def check_spelling(e=None):
        if not spell:
            show_snack("pyspellchecker non installé.", c(T.L_WARNING, T.D_WARNING))
            return
        save_content()
        d = doc()
        if not d:
            return
        wrong = spell.unknown(d["content"].split())
        if wrong:
            show_snack(f"{len(wrong)} faute(s) : {', '.join(list(wrong)[:8])}", c(T.L_WARNING, T.D_WARNING))
        else:
            show_snack("Aucune faute !", c(T.L_SUCCESS, T.D_SUCCESS))

    # ------------------------------------------------------------------
    # AI Grammar
    # ------------------------------------------------------------------
    def run_ai_check(e=None):
        save_content()
        d = doc()
        if not d or not d["content"].strip():
            show_snack("Rien à analyser.")
            return
        if not OllamaManager.is_ollama_installed():
            show_setup_dialog()
            return
        if not OllamaManager.is_server_running():
            show_snack("Démarrage d'Ollama…")
            OllamaManager.start_server()
            import time
            def retry():
                time.sleep(2.5)
                page.run_thread(run_ai_check)
            threading.Thread(target=retry, daemon=True).start()
            return
        if not OllamaManager.is_model_available():
            show_setup_dialog()
            return
        if s.checker and s.checker.is_running:
            show_snack("Analyse déjà en cours.")
            return

        s.show_ai = True
        s.ai_loading = True
        s.ai_error = ""
        s.ai_score = -1
        s.ai_corr = []
        s.ai_sugg = []
        rebuild()

        def on_result(corr, sugg, score):
            s.ai_corr = corr
            s.ai_sugg = sugg
            s.ai_score = score
            s.ai_loading = False
            page.run_thread(rebuild)

        def on_error(msg):
            s.ai_error = msg
            s.ai_loading = False
            page.run_thread(rebuild)

        s.checker = GrammarChecker(on_result=on_result, on_error=on_error)
        s.checker.check(d["content"].strip())

    def apply_correction(original, replacement):
        d = doc()
        if not d:
            return
        if original in d["content"]:
            d["content"] = d["content"].replace(original, replacement, 1)
            editor.value = d["content"]
            d["mod"] = True
            show_snack(f'"{original}" → "{replacement}"', c(T.L_SUCCESS, T.D_SUCCESS))
        else:
            show_snack(f'"{original}" introuvable.', c(T.L_WARNING, T.D_WARNING))

    # ------------------------------------------------------------------
    # Voice
    # ------------------------------------------------------------------
    def call_assistant(e=None):
        d = doc()
        if not d:
            return
        msg = "Bonjour, je suis Shadow Assistant. Comment puis-je vous aider ?\n"
        d["content"] = (editor.value or "") + msg
        editor.value = d["content"]
        d["mod"] = True
        rebuild()
        if TTS_AVAILABLE:
            threading.Thread(target=lambda: (pyttsx3.init().say(msg), pyttsx3.init().runAndWait()),
                             daemon=True).start()

    def read_text(e=None):
        if not TTS_AVAILABLE:
            show_snack("pyttsx3 non installé.", c(T.L_WARNING, T.D_WARNING))
            return
        save_content()
        d = doc()
        if not d or not d["content"].strip():
            show_snack("Rien à lire.")
            return
        if s.tts_on:
            show_snack("Lecture déjà en cours.")
            return
        s.tts_on = True
        show_snack("Lecture en cours…")
        text = d["content"]
        def speak():
            try:
                eng = pyttsx3.init()
                eng.say(text)
                eng.runAndWait()
            except Exception:
                pass
            s.tts_on = False
        threading.Thread(target=speak, daemon=True).start()

    def voice_typing(e=None):
        if not SR_AVAILABLE:
            show_snack("speech_recognition non installé.", c(T.L_WARNING, T.D_WARNING))
            return
        if s.voice_on:
            show_snack("Dictée en cours.")
            return
        s.voice_on = True
        show_snack("Parlez maintenant…")
        def listen():
            rec = sr.Recognizer()
            try:
                with sr.Microphone() as src:
                    audio = rec.listen(src, timeout=8, phrase_time_limit=15)
                text = rec.recognize_google(audio, language="fr-FR")
                d = doc()
                if d:
                    d["content"] = (d["content"] or "") + text
                    def _sync():
                        editor.value = d["content"]
                        rebuild()
                    page.run_thread(_sync)
            except Exception as exc:
                page.run_thread(lambda: show_snack(f"Erreur : {exc}"))
            s.voice_on = False
        threading.Thread(target=listen, daemon=True).start()

    def voice_ms(e=None):
        try:
            import pyautogui
            pyautogui.hotkey("win", "h")
        except Exception as exc:
            show_snack(str(exc))

    # ------------------------------------------------------------------
    # Dialogs
    # ------------------------------------------------------------------
    def show_setup_dialog():
        status = ft.Text("Vérification…", size=13, color=c(T.L_SECONDARY, T.D_SECONDARY))
        prog = ft.ProgressBar(visible=False, bar_height=6, border_radius=3)
        speed = ft.Text("", size=11, color=c(T.L_MUTED, T.D_MUTED), visible=False)
        action_btn = ft.Button("Vérifier", disabled=True)

        def check():
            if not OllamaManager.is_ollama_installed():
                status.value = "Ollama n'est pas installé."
                action_btn.text = "Installer Ollama"
                action_btn.disabled = False
                action_btn.on_click = lambda e: start_install()
            elif not OllamaManager.is_server_running():
                OllamaManager.start_server()
                status.value = "Démarrage…"
                import time
                threading.Timer(2.0, lambda: page.run_thread(check_model)).start()
            else:
                check_model()
            page.update()

        def check_model():
            if OllamaManager.is_model_available():
                status.value = f"✅ {OLLAMA_MODEL} prêt !"
                action_btn.text = "Fermer"
                action_btn.disabled = False
                action_btn.on_click = lambda e: page.pop_dialog()
            else:
                status.value = f"{OLLAMA_MODEL} non téléchargé."
                action_btn.text = f"Télécharger {OLLAMA_MODEL}"
                action_btn.disabled = False
                action_btn.on_click = lambda e: start_pull()
            page.update()

        def start_install():
            action_btn.disabled = True
            prog.visible = True
            speed.visible = True
            OllamaInstaller(
                on_progress=lambda p, m: page.run_thread(lambda: _upd_prog(p, m)),
                on_speed=lambda s: page.run_thread(lambda: _upd_speed(s)),
                on_done=lambda m: page.run_thread(lambda: (setattr_status(m), check())),
                on_error=lambda m: page.run_thread(lambda: setattr_status(f"Erreur: {m}")),
            ).start()

        def start_pull():
            action_btn.disabled = True
            prog.visible = True
            speed.visible = True
            ModelPuller(
                on_progress=lambda p, m: page.run_thread(lambda: _upd_prog(p, m)),
                on_speed=lambda s: page.run_thread(lambda: _upd_speed(s)),
                on_done=lambda: page.run_thread(check_model),
                on_error=lambda m: page.run_thread(lambda: setattr_status(f"Erreur: {m}")),
            ).start()

        def _upd_prog(p, m):
            prog.value = p / 100
            status.value = m
            page.update()

        def _upd_speed(s_val):
            speed.value = s_val
            page.update()

        def setattr_status(m):
            status.value = m
            prog.visible = False
            action_btn.disabled = False
            page.update()

        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Configuration — Correcteur IA", size=16, weight=ft.FontWeight.W_600),
            content=ft.Container(
                width=460,
                content=ft.Column(spacing=14, controls=[
                    ft.Text(f"Modèle : {OLLAMA_MODEL} ({MODEL_SIZE_DISPLAY}) • 100% local",
                            size=12, color=c(T.L_TERTIARY, T.D_TERTIARY)),
                    ft.Divider(color=c(T.L_BORDER, T.D_BORDER)),
                    status, prog, speed,
                ]),
            ),
            actions=[
                ft.TextButton("Fermer", on_click=lambda e: page.pop_dialog()),
                action_btn,
            ],
        )
        page.show_dialog(dlg)
        threading.Timer(0.3, lambda: page.run_thread(check)).start()

    def show_emoji_picker():
        search = ft.TextField(
            hint_text="Rechercher…", prefix_icon=ft.Icons.SEARCH,
            border_radius=8, text_size=14, height=44,
            border_color=c(T.L_BORDER, T.D_BORDER),
            focused_border_color=c(T.L_ACCENT, T.D_ACCENT),
        )
        result_grid = ft.GridView(max_extent=52, spacing=4, run_spacing=4, padding=8,
                                  expand=True, visible=False)

        cat_list = list(EMOJI_CATEGORIES.items())
        cat_grids = []
        cat_buttons_row = ft.Row(spacing=4, scroll=ft.ScrollMode.AUTO, controls=[])

        def make_emoji_btn(char, code):
            return ft.Container(
                width=48, height=48, border_radius=8, alignment=ft.Alignment(0, 0),
                ink=True, tooltip=code,
                on_click=lambda e, ch=char: _insert_emoji(ch),
                content=ft.Text(char, size=24),
            )

        for i, (cat_name, cat_dict) in enumerate(cat_list):
            short = cat_name.split("&")[0].strip().split(" ")[0]
            grid = ft.GridView(expand=True, max_extent=52, spacing=4, run_spacing=4,
                               padding=8, visible=(i == 0))
            for code, char in cat_dict.items():
                grid.controls.append(make_emoji_btn(char, code))
            cat_grids.append(grid)
            cat_buttons_row.controls.append(ft.Container(
                padding=ft.Padding(10, 6, 10, 6), border_radius=6, ink=True,
                bgcolor=c(T.L_SELECTED, T.D_SELECTED) if i == 0 else ft.Colors.TRANSPARENT,
                on_click=lambda e, idx=i: _switch_cat(idx),
                content=ft.Text(short, size=12, weight=ft.FontWeight.W_500,
                                color=c(T.L_ACCENT, T.D_ACCENT) if i == 0
                                else c(T.L_TERTIARY, T.D_TERTIARY)),
            ))

        grids_stack = ft.Stack(expand=True, controls=cat_grids)

        def _switch_cat(idx):
            for i, g in enumerate(cat_grids):
                g.visible = (i == idx)
            for i, btn in enumerate(cat_buttons_row.controls):
                btn.bgcolor = c(T.L_SELECTED, T.D_SELECTED) if i == idx else ft.Colors.TRANSPARENT
                btn.content.color = c(T.L_ACCENT, T.D_ACCENT) if i == idx \
                    else c(T.L_TERTIARY, T.D_TERTIARY)
            page.update()

        def on_search(e):
            q = (e.control.value or "").strip().lower()
            if not q:
                result_grid.visible = False
                cat_buttons_row.visible = True
                grids_stack.visible = True
                page.update()
                return
            result_grid.visible = True
            cat_buttons_row.visible = False
            grids_stack.visible = False
            result_grid.controls.clear()
            for code, char in EMOJI_DICT.items():
                if q in code.strip(":"):
                    result_grid.controls.append(make_emoji_btn(char, code))
            page.update()

        search.on_change = on_search

        def _insert_emoji(ch):
            d = doc()
            if d:
                d["content"] = (editor.value or "") + ch
                editor.value = d["content"]
                d["mod"] = True
            page.pop_dialog()
            rebuild()

        dlg = ft.AlertDialog(
            title=ft.Text("Émojis", size=16, weight=ft.FontWeight.W_600),
            content=ft.Container(
                width=520, height=420,
                content=ft.Column(spacing=10, controls=[
                    search, cat_buttons_row, result_grid, grids_stack,
                ]),
            ),
            actions=[
                ft.Text(f"{len(EMOJI_DICT)} émojis", size=12, color=c(T.L_MUTED, T.D_MUTED)),
                ft.TextButton("Fermer", on_click=lambda e: page.pop_dialog()),
            ],
        )
        page.show_dialog(dlg)

    def show_help():
        def row(label, key):
            return ft.Container(
                padding=ft.Padding(8, 6, 8, 6),
                content=ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        ft.Text(label, size=13, color=c(T.L_SECONDARY, T.D_SECONDARY)),
                        ft.Container(
                            padding=ft.Padding(10, 4, 10, 4), border_radius=6,
                            bgcolor=c(T.L_HOVER, T.D_HOVER),
                            content=ft.Text(key, size=12, weight=ft.FontWeight.W_500,
                                            color=c(T.L_TERTIARY, T.D_TERTIARY)),
                        ),
                    ],
                ),
            )
        dlg = ft.AlertDialog(
            title=ft.Text("Raccourcis clavier", size=16, weight=ft.FontWeight.W_600),
            content=ft.Container(
                width=440, height=380,
                content=ft.Column(scroll=ft.ScrollMode.AUTO, spacing=2, controls=[
                    row("Nouveau", "Ctrl+N"), row("Ouvrir", "Ctrl+O"),
                    row("Enregistrer", "Ctrl+S"), row("Enregistrer sous", "Ctrl+Shift+S"),
                    row("Imprimer", "Ctrl+P"),
                    row("Shadow Assistant", "F2"), row("Lire le texte", "F3"),
                    row("Dictée Google", "F4"), row("Dictée Microsoft", "F5"),
                    row("Orthographe", "F6"), row("Correcteur IA", "F7"),
                    row("Émojis", "Ctrl+E"),
                    ft.Divider(color=c(T.L_BORDER, T.D_BORDER)),
                    ft.Container(
                        padding=ft.Padding(8, 8, 8, 0),
                        content=ft.Text(
                            "Tapez :code + espace pour insérer un emoji.\n"
                            "Ex: :coeur :feu :ok :sourire :drapeau_fr",
                            size=13, color=c(T.L_TERTIARY, T.D_TERTIARY),
                        ),
                    ),
                ]),
            ),
            actions=[ft.TextButton("Fermer", on_click=lambda e: page.pop_dialog())],
        )
        page.show_dialog(dlg)

    def show_info():
        dlg = ft.AlertDialog(
            title=ft.Text("Informations", size=16, weight=ft.FontWeight.W_600),
            content=ft.Column(spacing=8, controls=[
                ft.Text(f"{APP_NAME} — v{APP_VERSION}", size=14, weight=ft.FontWeight.W_500),
                ft.Text("Éditeur de texte moderne avec IA locale.", size=13,
                        color=c(T.L_TERTIARY, T.D_TERTIARY)),
                ft.Text("Licence : CC BY-NC-ND 4.0", size=12,
                        color=c(T.L_MUTED, T.D_MUTED)),
            ]),
            actions=[ft.TextButton("Fermer", on_click=lambda e: page.pop_dialog())],
        )
        page.show_dialog(dlg)

    def show_credits():
        dlg = ft.AlertDialog(
            title=ft.Text("Crédits", size=16, weight=ft.FontWeight.W_600),
            content=ft.Container(
                width=420,
                content=ft.Column(spacing=10, controls=[
                    ft.Text("Développé par Arnaud", size=14, weight=ft.FontWeight.W_500,
                            color=c(T.L_PRIMARY, T.D_PRIMARY)),
                    ft.Text("• Python + Flet\n• pyspellchecker\n• pyttsx3\n"
                            "• SpeechRecognition\n• Ollama + ministral-3:3b",
                            size=13, color=c(T.L_SECONDARY, T.D_SECONDARY)),
                    ft.Text("CC BY-NC-ND 4.0", size=12, color=c(T.L_MUTED, T.D_MUTED)),
                ]),
            ),
            actions=[ft.TextButton("Fermer", on_click=lambda e: page.pop_dialog())],
        )
        page.show_dialog(dlg)

    def show_voice_menu():
        dlg = ft.AlertDialog(
            title=ft.Text("Fonctions vocales", size=16, weight=ft.FontWeight.W_600),
            content=ft.Container(
                width=360,
                content=ft.Column(spacing=8, controls=[
                    _dlg_btn("Lire le texte (F3)", ft.Icons.VOLUME_UP,
                             lambda e: (page.pop_dialog(), read_text())),
                    _dlg_btn("Dictée Google (F4)", ft.Icons.MIC,
                             lambda e: (page.pop_dialog(), voice_typing())),
                    _dlg_btn("Dictée Microsoft (F5)", ft.Icons.KEYBOARD_VOICE,
                             lambda e: (page.pop_dialog(), voice_ms())),
                ]),
            ),
            actions=[ft.TextButton("Fermer", on_click=lambda e: page.pop_dialog())],
        )
        page.show_dialog(dlg)

    def _dlg_btn(label, icon, on_click):
        return ft.Container(
            padding=ft.Padding(16, 12, 16, 12), border_radius=8, ink=True,
            on_click=on_click,
            border=ft.Border.all(1, c(T.L_BORDER, T.D_BORDER)),
            content=ft.Row(spacing=12, controls=[
                ft.Icon(icon, size=20, color=c(T.L_ACCENT, T.D_ACCENT)),
                ft.Text(label, size=14, color=c(T.L_PRIMARY, T.D_PRIMARY)),
            ]),
        )

    def show_options():
        dlg = ft.AlertDialog(
            title=ft.Text("Options", size=16, weight=ft.FontWeight.W_600),
            content=ft.Container(
                width=380,
                content=ft.Column(spacing=8, controls=[
                    _dlg_btn("Mode Texte", ft.Icons.EDIT_NOTE,
                             lambda e: (page.pop_dialog(), set_mode(MODE_TEXT))),
                    _dlg_btn("Mode Calcul", ft.Icons.CALCULATE_OUTLINED,
                             lambda e: (page.pop_dialog(), set_mode(MODE_CALC))),
                    _dlg_btn("Mode Lecture", ft.Icons.MENU_BOOK,
                             lambda e: (page.pop_dialog(), set_mode(MODE_READ))),
                    ft.Divider(color=c(T.L_BORDER, T.D_BORDER)),
                    ft.Container(
                        padding=ft.Padding(16, 12, 16, 12), border_radius=8,
                        border=ft.Border.all(1, c(T.L_BORDER, T.D_BORDER)),
                        content=ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.Row(spacing=12, controls=[
                                    ft.Icon(ft.Icons.DARK_MODE if dark() else ft.Icons.LIGHT_MODE,
                                            size=20, color=c(T.L_ACCENT, T.D_ACCENT)),
                                    ft.Text("Thème sombre" if dark() else "Thème clair",
                                            size=14, color=c(T.L_PRIMARY, T.D_PRIMARY)),
                                ]),
                                ft.Switch(value=dark(), active_color=c(T.L_ACCENT, T.D_ACCENT),
                                          on_change=lambda e: (page.pop_dialog(), toggle_theme())),
                            ],
                        ),
                    ),
                    ft.Divider(color=c(T.L_BORDER, T.D_BORDER)),
                    _dlg_btn("Aide", ft.Icons.HELP_OUTLINE,
                             lambda e: (page.pop_dialog(), show_help())),
                    _dlg_btn("Informations", ft.Icons.INFO_OUTLINE,
                             lambda e: (page.pop_dialog(), show_info())),
                    _dlg_btn("Crédits", ft.Icons.FAVORITE_BORDER,
                             lambda e: (page.pop_dialog(), show_credits())),
                ]),
            ),
            actions=[ft.TextButton("Fermer", on_click=lambda e: page.pop_dialog())],
        )
        page.show_dialog(dlg)

    def toggle_theme():
        page.theme_mode = ft.ThemeMode.LIGHT if dark() else ft.ThemeMode.DARK
        rebuild()

    # ------------------------------------------------------------------
    # Keyboard shortcuts
    # ------------------------------------------------------------------
    async def on_kb(e: ft.KeyboardEvent):
        if e.ctrl and e.key == "N":
            add_tab()
        elif e.ctrl and e.key == "O":
            await open_file()
        elif e.ctrl and e.shift and e.key == "S":
            await save_file_as()
        elif e.ctrl and e.key == "S":
            await save_file()
        elif e.ctrl and e.key == "E":
            show_emoji_picker()
        elif e.ctrl and e.key == "P":
            print_file()
        elif e.key == "F1":
            show_help()
        elif e.key == "F2":
            call_assistant()
        elif e.key == "F3":
            read_text()
        elif e.key == "F4":
            voice_typing()
        elif e.key == "F5":
            voice_ms()
        elif e.key == "F6":
            check_spelling()
        elif e.key == "F7":
            run_ai_check()

    page.on_keyboard_event = on_kb

    # ------------------------------------------------------------------
    # Build UI
    # ------------------------------------------------------------------
    def build_sidebar():
        def item(label, icon, key, on_click=None, badge=None):
            active = (s.sidebar_key == key)
            ctrls = [
                ft.Icon(icon, size=20,
                        color=c(T.L_ACCENT, T.D_ACCENT) if active else c(T.L_TERTIARY, T.D_TERTIARY)),
                ft.Text(label, size=13, expand=True,
                        weight=ft.FontWeight.W_500 if active else ft.FontWeight.W_400,
                        color=c(T.L_PRIMARY, T.D_PRIMARY) if active else c(T.L_SECONDARY, T.D_SECONDARY)),
            ]
            if badge:
                ctrls.append(ft.Container(
                    width=24, height=20, border_radius=10,
                    bgcolor=c(T.L_ACCENT_LT, T.D_ACCENT_LT), alignment=ft.Alignment(0, 0),
                    content=ft.Text(str(badge), size=10, color=c(T.L_ACCENT, T.D_ACCENT),
                                    weight=ft.FontWeight.W_500),
                ))
            return ft.Container(
                padding=ft.Padding(12, 10, 12, 10), border_radius=8,
                bgcolor=c(T.L_SELECTED, T.D_SELECTED) if active else ft.Colors.TRANSPARENT,
                ink=True, on_click=on_click,
                content=ft.Row(controls=ctrls, spacing=12),
            )

        return ft.Container(
            width=240, bgcolor=c(T.L_SIDEBAR, T.D_SIDEBAR),
            border=ft.Border.only(right=ft.BorderSide(1, c(T.L_BORDER, T.D_BORDER))),
            padding=ft.Padding(12, 16, 12, 12),
            content=ft.Column(expand=True, spacing=0, controls=[
                # Logo
                ft.Container(
                    padding=ft.Padding(12, 0, 0, 20),
                    content=ft.Row(spacing=10, controls=[
                        ft.Container(
                            width=32, height=32, border_radius=8,
                            bgcolor=c(T.L_ACCENT, T.D_ACCENT), alignment=ft.Alignment(0, 0),
                            content=ft.Text("S", size=16, weight=ft.FontWeight.BOLD, color="#FFFFFF"),
                        ),
                        ft.Column(spacing=0, controls=[
                            ft.Text(APP_NAME, size=15, weight=ft.FontWeight.W_600,
                                    color=c(T.L_PRIMARY, T.D_PRIMARY)),
                            ft.Text(f"v{APP_VERSION}", size=11, color=c(T.L_MUTED, T.D_MUTED)),
                        ]),
                    ]),
                ),
                # Nav
                ft.Column(spacing=2, controls=[
                    item("Documents", ft.Icons.DESCRIPTION_OUTLINED, "docs"),
                    item("Assistant", ft.Icons.SMART_TOY_OUTLINED, "assistant",
                         on_click=lambda e: call_assistant()),
                    item("Correcteur IA", ft.Icons.SPELLCHECK, "ai",
                         on_click=lambda e: run_ai_check()),
                    item("Orthographe", ft.Icons.ABC, "spell",
                         on_click=lambda e: check_spelling()),
                    item("Émojis", ft.Icons.EMOJI_EMOTIONS_OUTLINED, "emoji",
                         badge=len(EMOJI_DICT), on_click=lambda e: show_emoji_picker()),
                    item("Voix", ft.Icons.MIC_NONE, "voice",
                         on_click=lambda e: show_voice_menu()),
                ]),
                ft.Container(expand=True),
                ft.Container(height=1, bgcolor=c(T.L_BORDER, T.D_BORDER),
                             margin=ft.Margin(12, 4, 12, 4)),
                ft.Column(spacing=2, controls=[
                    item("Aide", ft.Icons.HELP_OUTLINE, "help",
                         on_click=lambda e: show_help()),
                    item("Options", ft.Icons.SETTINGS_OUTLINED, "opts",
                         on_click=lambda e: show_options()),
                ]),
            ]),
        )

    def build_tab_bar():
        tabs = []
        for i, d in enumerate(s.docs):
            active = (i == s.idx)
            title = d["title"] + (" •" if d["mod"] else "")
            tabs.append(ft.Container(
                on_click=lambda e, idx=i: switch_tab(idx),
                padding=ft.Padding(14, 8, 6, 8),
                border=ft.Border.only(
                    bottom=ft.BorderSide(2, c(T.L_ACCENT, T.D_ACCENT) if active
                                         else ft.Colors.TRANSPARENT)
                ),
                ink=True,
                content=ft.Row(spacing=6, controls=[
                    ft.Icon(ft.Icons.DESCRIPTION_OUTLINED, size=15,
                            color=c(T.L_ACCENT, T.D_ACCENT) if active
                            else c(T.L_TERTIARY, T.D_TERTIARY)),
                    ft.Text(title, size=13,
                            weight=ft.FontWeight.W_500 if active else ft.FontWeight.W_400,
                            color=c(T.L_PRIMARY, T.D_PRIMARY) if active
                            else c(T.L_TERTIARY, T.D_TERTIARY)),
                    ft.IconButton(
                        icon=ft.Icons.CLOSE, icon_size=14,
                        icon_color=c(T.L_MUTED, T.D_MUTED), tooltip="Fermer",
                        style=ft.ButtonStyle(padding=2, shape=ft.RoundedRectangleBorder(radius=4)),
                        on_click=lambda e, idx=i: close_tab(idx),
                    ),
                ]),
            ))
        return ft.Container(
            border=ft.Border.only(bottom=ft.BorderSide(1, c(T.L_BORDER, T.D_BORDER))),
            bgcolor=c(T.L_BG, T.D_BG), padding=ft.Padding(8, 0, 0, 0),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Row(spacing=0, scroll=ft.ScrollMode.AUTO, expand=True, controls=tabs),
                    ft.Container(
                        padding=ft.Padding(0, 0, 8, 0),
                        content=ft.IconButton(
                            icon=ft.Icons.ADD, icon_size=18, tooltip="Nouvel onglet",
                            icon_color=c(T.L_TERTIARY, T.D_TERTIARY),
                            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=6), padding=6),
                            on_click=lambda e: add_tab(),
                        ),
                    ),
                ],
            ),
        )

    def build_menu_bar():
        async def do_open(e):  await open_file()
        async def do_save(e):  await save_file()
        async def do_save_as(e): await save_file_as()

        def menu_btn(label, icon, on_click, shortcut=None):
            tip = f"{label}  {shortcut}" if shortcut else label
            return ft.TextButton(
                content=ft.Row(spacing=6, tight=True, controls=[
                    ft.Icon(icon, size=15, color=c(T.L_SECONDARY, T.D_SECONDARY)),
                    ft.Text(label, size=13, color=c(T.L_SECONDARY, T.D_SECONDARY)),
                ]),
                tooltip=tip,
                style=ft.ButtonStyle(
                    shape=ft.RoundedRectangleBorder(radius=6),
                    padding=ft.Padding(10, 6, 10, 6),
                    overlay_color={ft.ControlState.HOVERED: c(T.L_HOVER, T.D_HOVER)},
                ),
                on_click=on_click,
            )

        def sep():
            return ft.Container(width=1, height=20, bgcolor=c(T.L_BORDER, T.D_BORDER),
                                margin=ft.Margin(4, 0, 4, 0))

        menu = ft.Container(
            padding=ft.Padding(8, 4, 8, 4), border_radius=10,
            bgcolor=c(T.L_TOOLBAR, T.D_TOOLBAR),
            border=ft.Border.all(1, c(T.L_TB_BORDER, T.D_TB_BORDER)),
            shadow=ft.BoxShadow(spread_radius=0, blur_radius=8,
                                color=ft.Colors.with_opacity(0.06, ft.Colors.BLACK),
                                offset=ft.Offset(0, 2)),
            content=ft.Row(spacing=2, controls=[
                menu_btn("Ouvrir",          ft.Icons.FOLDER_OPEN_OUTLINED, do_open,   "Ctrl+O"),
                menu_btn("Nouveau",         ft.Icons.ADD_CIRCLE_OUTLINE,   lambda e: add_tab(), "Ctrl+N"),
                sep(),
                menu_btn("Enregistrer",     ft.Icons.SAVE_OUTLINED,        do_save,   "Ctrl+S"),
                menu_btn("Enregistrer sous",ft.Icons.SAVE_AS_OUTLINED,     do_save_as,"Ctrl+Shift+S"),
                sep(),
                menu_btn("Renommer",        ft.Icons.EDIT_OUTLINED,        lambda e: rename_file()),
                menu_btn("Imprimer",        ft.Icons.PRINT_OUTLINED,       lambda e: print_file(), "Ctrl+P"),
            ]),
        )
        return ft.Row(
            alignment=ft.MainAxisAlignment.CENTER,
            controls=[ft.Container(content=menu, margin=10)],
        )

    def build_status():
        return ft.Container(
            height=36, bgcolor=c(T.L_STATUS, T.D_STATUS),
            border=ft.Border.only(top=ft.BorderSide(1, c(T.L_BORDER, T.D_BORDER))),
            padding=ft.Padding(20, 0, 20, 0),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Row(spacing=16, controls=[st_mode, st_msg]),
                    ft.Row(spacing=16, controls=[st_chars, st_words]),
                ],
            ),
        )

    def build_ai_panel():
        if not s.show_ai:
            return ft.Container(visible=False)

        items = []
        # Header
        items.append(ft.Container(
            padding=ft.Padding(16, 14, 16, 14),
            border=ft.Border.only(bottom=ft.BorderSide(1, c(T.L_BORDER, T.D_BORDER))),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    ft.Text("Corrections IA", size=14, weight=ft.FontWeight.W_600,
                            color=c(T.L_PRIMARY, T.D_PRIMARY)),
                    ft.IconButton(icon=ft.Icons.CLOSE, icon_size=18,
                                  icon_color=c(T.L_MUTED, T.D_MUTED),
                                  on_click=lambda e: _close_ai()),
                ],
            ),
        ))

        if s.ai_loading:
            items.append(ft.Container(
                padding=40, alignment=ft.Alignment(0, 0),
                content=ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=16,
                                  controls=[
                    ft.ProgressRing(width=32, height=32, color=c(T.L_ACCENT, T.D_ACCENT)),
                    ft.Text(f"Analyse avec {OLLAMA_MODEL}…", size=13,
                            color=c(T.L_TERTIARY, T.D_TERTIARY)),
                ]),
            ))
        elif s.ai_error:
            items.append(ft.Container(
                padding=24,
                content=ft.Row(spacing=10, controls=[
                    ft.Icon(ft.Icons.ERROR_OUTLINE, color=c(T.L_ERROR, T.D_ERROR), size=20),
                    ft.Text(s.ai_error, size=13, color=c(T.L_ERROR, T.D_ERROR), expand=True),
                ]),
            ))
        elif s.ai_score >= 0:
            sc = c(T.L_SUCCESS, T.D_SUCCESS) if s.ai_score >= 80 \
                else c(T.L_WARNING, T.D_WARNING) if s.ai_score >= 50 \
                else c(T.L_ERROR, T.D_ERROR)
            items.append(ft.Container(
                padding=20,
                content=ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8,
                                  controls=[
                    ft.Text(str(s.ai_score), size=36, weight=ft.FontWeight.BOLD, color=sc),
                    ft.Text("Score de qualité", size=12, color=c(T.L_TERTIARY, T.D_TERTIARY)),
                    ft.ProgressBar(value=s.ai_score / 100, color=sc,
                                   bgcolor=c(T.L_BORDER, T.D_BORDER), bar_height=6, border_radius=3),
                ]),
            ))

            for cr in s.ai_corr:
                dot_colors = {"orthographe": "#DC2626", "grammaire": "#EA580C",
                              "conjugaison": "#9333EA", "accord": "#2563EB", "ponctuation": "#059669"}
                dc = dot_colors.get(cr.get("type", "").lower(), "#DC2626")
                items.append(ft.Container(
                    padding=ft.Padding(16, 12, 16, 12),
                    border=ft.Border.only(bottom=ft.BorderSide(1, c(T.L_BORDER, T.D_BORDER))),
                    content=ft.Column(spacing=6, controls=[
                        ft.Row(spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER,
                               controls=[
                            ft.Container(width=8, height=8, border_radius=4, bgcolor=dc),
                            ft.Text(cr["original"], size=13,
                                    style=ft.TextStyle(decoration=ft.TextDecoration.LINE_THROUGH),
                                    color=c(T.L_ERROR, T.D_ERROR)),
                            ft.Text("→", size=13, color=c(T.L_MUTED, T.D_MUTED)),
                            ft.Text(cr["correction"], size=13, weight=ft.FontWeight.W_500,
                                    color=c(T.L_SUCCESS, T.D_SUCCESS)),
                        ]),
                        ft.Text(f"{cr.get('type','').capitalize()} — {cr.get('explication','')}",
                                size=11, color=c(T.L_MUTED, T.D_MUTED)),
                        ft.Row(spacing=8, controls=[
                            ft.OutlinedButton("Appliquer", height=28, style=ft.ButtonStyle(
                                color=c(T.L_SUCCESS, T.D_SUCCESS),
                                side=ft.BorderSide(1, c(T.L_SUCCESS, T.D_SUCCESS)),
                                shape=ft.RoundedRectangleBorder(radius=6),
                                padding=ft.Padding(12, 0, 12, 0),
                                text_style=ft.TextStyle(size=11)),
                                on_click=lambda e, o=cr["original"], r=cr["correction"]:
                                    apply_correction(o, r)),
                            ft.OutlinedButton("Ignorer", height=28, style=ft.ButtonStyle(
                                color=c(T.L_MUTED, T.D_MUTED),
                                side=ft.BorderSide(1, c(T.L_BORDER, T.D_BORDER)),
                                shape=ft.RoundedRectangleBorder(radius=6),
                                padding=ft.Padding(12, 0, 12, 0),
                                text_style=ft.TextStyle(size=11))),
                        ]),
                    ]),
                ))

            for sg in s.ai_sugg:
                items.append(ft.Container(
                    padding=ft.Padding(16, 12, 16, 12),
                    border=ft.Border.only(bottom=ft.BorderSide(1, c(T.L_BORDER, T.D_BORDER))),
                    content=ft.Column(spacing=6, controls=[
                        ft.Row(spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER,
                               controls=[
                            ft.Container(width=8, height=8, border_radius=4, bgcolor="#8B5CF6"),
                            ft.Text(sg["original"], size=13, color=c(T.L_SECONDARY, T.D_SECONDARY)),
                            ft.Text("→", size=13, color=c(T.L_MUTED, T.D_MUTED)),
                            ft.Text(sg["suggestion"], size=13, weight=ft.FontWeight.W_500,
                                    color="#8B5CF6"),
                        ]),
                        ft.Text(f"{sg.get('type','').capitalize()} — {sg.get('explication','')}",
                                size=11, color=c(T.L_MUTED, T.D_MUTED)),
                        ft.Row(spacing=8, controls=[
                            ft.OutlinedButton("Appliquer", height=28, style=ft.ButtonStyle(
                                color="#8B5CF6", side=ft.BorderSide(1, "#8B5CF6"),
                                shape=ft.RoundedRectangleBorder(radius=6),
                                padding=ft.Padding(12, 0, 12, 0),
                                text_style=ft.TextStyle(size=11)),
                                on_click=lambda e, o=sg["original"], r=sg["suggestion"]:
                                    apply_correction(o, r)),
                            ft.OutlinedButton("Ignorer", height=28, style=ft.ButtonStyle(
                                color=c(T.L_MUTED, T.D_MUTED),
                                side=ft.BorderSide(1, c(T.L_BORDER, T.D_BORDER)),
                                shape=ft.RoundedRectangleBorder(radius=6),
                                padding=ft.Padding(12, 0, 12, 0),
                                text_style=ft.TextStyle(size=11))),
                        ]),
                    ]),
                ))

            if not s.ai_corr and not s.ai_sugg:
                items.append(ft.Container(
                    padding=24, alignment=ft.Alignment(0, 0),
                    content=ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8,
                                      controls=[
                        ft.Text("✨", size=32),
                        ft.Text("Texte parfait !", size=14, weight=ft.FontWeight.W_500,
                                color=c(T.L_SUCCESS, T.D_SUCCESS)),
                    ]),
                ))
        else:
            items.append(ft.Container(
                padding=40, alignment=ft.Alignment(0, 0),
                content=ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=12,
                                  controls=[
                    ft.Icon(ft.Icons.SPELLCHECK, size=40, color=c(T.L_MUTED, T.D_MUTED)),
                    ft.Text("Appuyez sur F7", size=13, color=c(T.L_TERTIARY, T.D_TERTIARY)),
                ]),
            ))

        return ft.Container(
            width=340, bgcolor=c(T.L_SURFACE, T.D_SURFACE),
            border=ft.Border.only(left=ft.BorderSide(1, c(T.L_BORDER, T.D_BORDER))),
            content=ft.Column(spacing=0, expand=True, scroll=ft.ScrollMode.AUTO, controls=items),
        )

    def _close_ai():
        s.show_ai = False
        rebuild()

    # ------------------------------------------------------------------
    # Full rebuild
    # ------------------------------------------------------------------
    def rebuild():
        update_status()
        editor.hint_style = ft.TextStyle(size=15, color=c(T.L_MUTED, T.D_MUTED), italic=True)
        editor.text_style = ft.TextStyle(size=16, height=1.7, color=c(T.L_PRIMARY, T.D_PRIMARY))
        editor.cursor_color = c(T.L_ACCENT, T.D_ACCENT)
        editor.read_only = (s.mode == MODE_READ)
        st_mode.color = c(T.L_ACCENT, T.D_ACCENT)
        st_chars.color = c(T.L_TERTIARY, T.D_TERTIARY)
        st_words.color = c(T.L_TERTIARY, T.D_TERTIARY)

        page.controls.clear()
        page.add(ft.Row(expand=True, spacing=0, controls=[
            build_sidebar(),
            ft.Column(expand=True, spacing=0, controls=[
                build_tab_bar(),
                ft.Container(
                    expand=True, bgcolor=c(T.L_EDITOR, T.D_EDITOR),
                    content=ft.Column(expand=True, spacing=0, controls=[
                        build_menu_bar(),
                        ft.Container(expand=True, content=editor),
                    ]),
                ),
                build_status(),
            ]),
            build_ai_panel(),
        ]))
        page.update()

    # ------------------------------------------------------------------
    # Initial render
    # ------------------------------------------------------------------
    update_status()
    rebuild()


# ===========================================================================
# Entry point
# ===========================================================================

if __name__ == "__main__":
    ft.run(main)
